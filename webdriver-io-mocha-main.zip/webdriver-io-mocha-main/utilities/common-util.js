class CommonUtils{

    switchToModal(){

    }

    captureScreenshot(path){
        browser.saveScreenshot(path);
    }

}

export default new CommonUtils();