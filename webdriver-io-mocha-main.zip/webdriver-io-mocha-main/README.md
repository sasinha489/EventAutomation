# # webdriver-io-mocha"

This repository contains page object model based webdriver-io implementation with mocha.

# Pre-requisite:

1. Node should be installed in PC
2. JAVA 8 and above should be installed in PC
3. VS code as editor.

# How to get started

Once you clone the project

run npm-install to download all the dependencies from package.json.

Now you are all set to go.

# How to run the test

npm run test-local would kick start test in local PC.

This framework can be extended to connet to browserstack or sauce lab for test execution.
